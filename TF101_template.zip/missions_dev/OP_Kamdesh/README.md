# OP_Kamdesh - 前哨決戰（Prototype）

此資料夾為任務三《The Outpost》改編任務的開發區。

## 任務概述
- 地圖：Lythium
- 任務類型：防守型劇情任務
- 支援模組：Simplex、RHS、美軍裝備包
- 設計進度：初步架構已完成，等待模組整合清單套入

## 文件結構
- mission.sqm：Eden 任務主檔
- stringtable.xml：中文翻譯表
- support_call.sqf：支援系統腳本
